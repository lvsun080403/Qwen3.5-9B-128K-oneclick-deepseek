# dsh-local-model-toggle 0.5.1（只装插件）

给 DeepSeek Harness 加一颗"本地模型开关"：左下角一个蓝色胶囊，左键启停本地 llama.cpp 服务，右键切换是哪一个本地模型、换部署夹、设闲置自动关闭。

**这个包只装插件**，不会下载模型或运行时 —— 前提是你机器上已经有一个能跑的部署目录（里面有 `qwen-deploy.ps1` 或 `serve-bonsai.ps1`，以及 `llama.cpp\models\*.gguf`）。

---

## 0.5.1 修了什么

**「选择部署夹…」点了没反应、只说“没选文件夹”** —— 两个原因叠加：

1. 生成给 PowerShell 的临时脚本是 UTF-8 **无 BOM**，PowerShell 5.1 按 ANSI 读，里面的中文全部变乱码 → 脚本语法错，一行没跑就退出。
2. 即使能跑，`FolderBrowserDialog.ShowDialog()` 在“隐藏启动、没有控制台”的进程里会**立刻返回 Cancel**（目录框根本没弹）。修法是给它一个不可见的 owner 窗体当父窗口，再 `ShowDialog($owner)`。

现在点「选择部署夹…」会真的弹出系统目录框；真按取消才显示“已取消”，弹不出来会把失败原因显示出来。

---
## 0.5.0 相比上一版多了什么

| | 上一版 | 0.5.0 |
|---|---|---|
| 模型来源 | 写死一个 `local-qwen` | 自动读 `cordis.patch.yml`，列出**所有**指向本机的 provider |
| 行内文字 | 固定「本地 Qwen3.5-9B」 | 跟着当前选中的模型变 |
| 右键菜单 | 只有部署夹 / 闲置开关 | 顶部多一个模型列表，点一下就切 |
| 停止方式 | `taskkill /IM llama-server.exe`（会杀掉全部本地模型） | 只杀监听该端口的那一个进程 |
| 部署夹 | 全局一个 | 每个模型一份（config v2 的 `dirs`） |

---

## 1. 目录里有什么

```
dsh-local-model-toggle-plugin-0.5.1\
├─ install.bat          ← 双击这个安装
├─ uninstall.bat        ← 双击这个卸载
├─ setup.ps1            安装逻辑（被 bat 调用）
├─ uninstall.ps1        卸载逻辑
├─ package.json         插件清单（0.5.0）
├─ cordis.patch.yml     插件自己的 bundle 声明
├─ lib\
│  ├─ index.js          宿主半边：HTTP 路由、发现模型、启停进程
│  └─ client.js         浏览器半边：侧栏那颗胶囊 + 右键菜单
├─ docs\screenshot.png  长什么样
├─ LICENSE
└─ README.md            就是这份
```

---

## 2. 安装

### 2.1 最简单：双击

1. 双击 **`install.bat`**
2. 如果它提示"没找到部署目录"，把**部署文件夹拖到 `install.bat` 上**松手，它会当成 `-DeployDir` 参数传进去
3. 看到 `[+] 装好了` 后：**完全退出 DSH（托盘右键 → 退出）再重新打开**

### 2.2 命令行（可带参数）

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -DeployDir "D:\1\Qwen3.5-9B · Q4_K_XL"
```

| 参数 | 说明 |
|---|---|
| `-DeployDir <路径>` | 部署夹。不传则沿用 `~\.dsh\local-model-toggle\config.json` 里记过的；都没有就报错停下，不乱猜 |
| `-Provider <id>` | 这份部署夹属于哪个 provider。不传则自动挑（端口 8080 优先，其次端口最小） |
| `-NoStart` | 只装，不顺手拉起模型服务 |
| `-DryRun` | 只打印将要做什么，不写任何文件 |
| `-ProfileDir` / `-PluginRoot` / `-DshHome` | 一般不用动，默认 `~\.dsh\...` |

脚本是**幂等**的：重跑不会重复登记 bundle，只会更新文件与配置。

---

## 3. 装完怎么用

重启 DSH 后，左下角（设置齿轮上方）出现蓝色胶囊：

- **左键**：启动 / 停止**当前选中**的本地模型
- **右键**：弹菜单 —— 上半部分是模型列表（前面是运行指示灯，右边是端口），点一下切换；下半部分是当前模型的部署夹、`选择部署夹…`、闲置自动关闭开关与分钟数
- 启动过程中，胶囊上方会浮出一个终端卡，实时滚动真实的启动日志

---

## 4. 它怎么识别"本地模型"

只认 `~\.dsh\profiles\desktop\cordis.patch.yml` 里 `llm-pi-ai.config.providers` 下、`baseURL` 指向本机回环地址的条目：

```
http://127.0.0.1:8080/v1     ✓
http://localhost:8081/v1     ✓
http://[::1]:9000/v1         ✓
https://gateway.example/v1   ✗ 远程中转站，不纳入
```

所以想让它看到第二个模型，得先在 DSH 里加一条「自定义模型 API」，或者手改 `cordis.patch.yml` 加一个 provider。

> 注意：DSH 设置页保存时在这台机器上会报 `dsh: profile reload requires the root Include entry` 并回滚（已知问题），改 `cordis.patch.yml` 只能手工编辑后重启 DSH。

---

## 5. 写进去的配置文件

`~\.dsh\local-model-toggle\config.json`（UTF-8 无 BOM）：

```json
{
  "version": 2,
  "active": "local-qwen",
  "autoStop": true,
  "idleMinutes": 10,
  "dirs": { "local-qwen": "D:\\1\\Qwen3.5-9B · Q4_K_XL" }
}
```

- `active`：当前选中的 provider id（右键菜单里点一下就改）
- `dirs`：每个 provider 各自的部署夹
- `autoStop` / `idleMinutes`：闲置多久自动停（看 `/metrics` 的请求计数，不是猜）
- 旧的 `deployDir` 字段仍兼容，会自动迁移

---

## 6. 卸载

双击 **`uninstall.bat`**，或：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\uninstall.ps1
```

会删掉 Junction、插件目录、`package.json` 里的依赖与 bundle（改前自动备份 `package.json.bak-toggle-*`）。配置文件保留，方便你以后重装继续用；想彻底删就自己删 `~\.dsh\local-model-toggle\`。

---

## 7. 手工装（不想跑脚本）

1. 把整个文件夹复制到 `%USERPROFILE%\.dsh\plugins\dsh-local-model-toggle`
2. 在 `%USERPROFILE%\.dsh\profiles\desktop\node_modules\` 下建 Junction：
   `cmd /c mklink /J "…\node_modules\dsh-local-model-toggle" "…\.dsh\plugins\dsh-local-model-toggle"`
3. 改 `%USERPROFILE%\.dsh\profiles\desktop\package.json`：
   - `dependencies` 加 `"dsh-local-model-toggle": "link:D:/…/.dsh/plugins/dsh-local-model-toggle"`
   - `dsh.profile.bundles` 里加上 `"dsh-local-model-toggle"`
4. 写配置文件（见第 5 节）
5. 完全退出 DSH 再打开

---

## 8. 已知限制

- 只识别 `baseURL` 为本机回环的 provider；远程中转站不会出现在菜单里
- 停止模型依赖 `netstat -ano -p TCP` 找端口对应的 PID（PowerShell 5.1 里 `Get-NetTCPConnection` 不一定有）
- 插件跟着 DSH 的 API Key 走：它**不**读写 `api-key.txt`，启停只是调部署脚本
- `docs\screenshot.png` 是按 CSS 数值重绘的示意图，不是实机截图

---

MIT License · 作者：你自己 · 版本 0.5.0
