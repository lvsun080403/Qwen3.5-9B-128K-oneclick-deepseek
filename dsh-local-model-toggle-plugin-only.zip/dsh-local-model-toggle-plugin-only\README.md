﻿# dsh-local-model-toggle

给 DeepSeek Harness（DSH）侧栏左下角加一个开关：一键启停本地 llama.cpp（Qwen3.5-9B）服务。
A one-click on/off switch in the DSH sidebar footer for a local llama.cpp server.

![screenshot](docs/screenshot.png)

## 它能做什么

- **左键**：启动 / 停止本地模型服务（调用部署目录里的 `start-qwen.bat` 背后的 `qwen-deploy.ps1`）。
- **右键**：弹出面板 —— 选择部署目录、配置「闲置 N 分钟自动关闭」、查看最近日志。
- **启动时**：开关上方浮出一张「终端卡」，逐字打出真实的启动日志（不是假进度条），服务就绪后自动消失。
- **找不到部署目录时**：开关变红并提示，左键直接打开目录选择器。

## 前置条件

1. 已经用 `qwen-deploy.ps1` 部署好本地模型，目录里至少有：
   - `qwen-deploy.ps1`
   - `start-qwen.bat`
   - `llama.cpp\`（运行时 + `models\*.gguf`）
2. DSH 版本支持浏览器插件（`dsh.client.platform === "web"`）与 `sidebar.footer.action` 槽位。

插件本身不下载模型、不装运行时，只负责启停那个已存在的部署目录。

## 目录结构

```text
dsh-local-model-toggle\
  lib\index.js        宿主侧（HTTP 路由、起停、闲置看门狗）
  lib\client.js       浏览器侧（胶囊开关、悬浮终端卡、右键面板）
  cordis.patch.yml    插件注册（- insert:）
  package.json        含 dsh.bundle / dsh.client 声明
  setup.ps1           一键：装插件 + 写配置（可选顺手起服务）
  uninstall.ps1       撤销安装
```

## 安装（模型已有，只装插件）

```powershell
# 在本文件夹里执行，把路径换成你自己的部署目录
powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -DeployDir "D:\1\Qwen3.5-9B · Q4_K_XL"

# 先看看它会做什么，不落盘
powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -DryRun

# 装完不启动模型（只想装插件）
powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -DeployDir "..." -NoStart
```

它只做三件事，不会下载任何东西：

1. **装插件** —— 复制到 `%USERPROFILE%\.dsh\plugins\dsh-local-model-toggle`，在 profile 的 `node_modules` 里建 Junction，并在 `package.json` 里登记依赖与 bundle（改前备份为 `package.json.bak-toggle-<时间>`）。
2. **写配置** —— `%USERPROFILE%\.dsh\local-model-toggle\config.json`，记下 `deployDir` 与「闲置 10 分钟自动关闭」。
3. **起服务**（可用 `-NoStart` 跳过）—— 已经在跑就跳过；否则调部署目录里的 `qwen-deploy.ps1 -Background`，最多等 10 分钟 `/health` 200。

不传 `-DeployDir` 时会沿用上次写过的 `config.json`；两者都没有就停下并提示，不会乱猜路径。脚本幂等，重跑不会重复登记 bundle。

做完**完全退出 DSH 再打开**（托盘右键 → 退出）。

## 手动安装（不想跑脚本时）

1. 把本文件夹复制到 `%USERPROFILE%\.dsh\plugins\dsh-local-model-toggle`。
2. 建 Junction：
   ```cmd
   mklink /J "%USERPROFILE%\.dsh\profiles\desktop\node_modules\dsh-local-model-toggle" "%USERPROFILE%\.dsh\plugins\dsh-local-model-toggle"
   ```
3. 编辑 `%USERPROFILE%\.dsh\profiles\desktop\package.json`：
   - `dependencies` 里加 `"dsh-local-model-toggle": "link:C:/Users/<你>/.dsh/plugins/dsh-local-model-toggle"`
   - `dsh.profile.bundles` 数组里加 `"dsh-local-model-toggle"`（放在最后一个 `@deepseek-ai/...` 之前或之后都行）
4. 完全退出 DSH 再打开。

## 使用

- 第一次点开关时如果还没选部署目录，会弹出 Windows 文件夹选择框；选中含 `qwen-deploy.ps1` 的目录即可。
- 路径记在 `%USERPROFILE%\.dsh\local-model-toggle\config.json`：
  ```json
  { "deployDir": "D:\\1\\Qwen3.5-9B · Q4_K_XL", "autoStop": true, "idleMinutes": 10 }
  ```
- 闲置自动关闭靠轮询 llama.cpp 的 `/metrics`（`requests_processing` 与各 token 计数器都不涨才算闲置），刚启动 60 秒内不判。

## 卸载

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\uninstall.ps1
```

恢复 `package.json` 备份、删掉 Junction 与插件目录，然后完全退出 DSH 再打开。

## 已知限制

- DSH 的 `profile reload requires the root Include entry` 是宿主自身的 bug：改完配置**必须重启 DSH**，热重载会报这句错并把改动回滚。
- 客户端模块按版本号缓存。升级后如果界面没变化，把 `package.json` 的 `version` 撞一下（例如 `0.4.9` → `0.4.10`）再重启。
- 脚本启动用 `powershell.exe`（Windows PowerShell 5.1）；启动瞬间如果缺 VC++ 运行库或显卡驱动，`qwen-deploy.ps1` 会自己报错，日志会显示在悬浮卡里。

## 开发

源码里另有一套离线测试（不随包发布）：

- `test-render.mjs` —— 用 stub React 渲染组件，断言样式与 DOM 结构。
- `test-boot.mjs` —— 用真实 cordis 挂载客户端插件，断言 `inject` 声明正确、能进入 active。
- `test-harness.mjs` —— 假 webServer + 真 HTTP，验证 `/status` `/toggle` `/config` `/log` 等路由与鉴权。

## 许可

MIT
