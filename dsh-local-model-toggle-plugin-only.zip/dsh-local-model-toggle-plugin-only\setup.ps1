﻿# dsh-local-model-toggle 安装脚本（只装插件，模型已经有了）
#
# 前提：你机器上已经有一个 llama.cpp 部署目录，里面至少有
#   qwen-deploy.ps1、start-qwen.bat、llama.cpp\llama-server.exe、llama.cpp\models\*.gguf
#
# 这个脚本只做三件事：
#   1. 把插件装进 DSH profile（复制 + Junction + 登记依赖与 bundle）
#   2. 写插件配置，告诉它部署目录在哪
#   3. 可选：顺手把模型服务拉起来
#
# 用法（在本文件夹里）：
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -DeployDir "D:\1\Qwen3.5-9B · Q4_K_XL"
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -DeployDir "..." -NoStart
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -DryRun
#
# 不传 -DeployDir 时会沿用上次写过的 config.json；两者都没有就停下，不乱猜。

param(
    [string]$DeployDir = '',
    [string]$ProfileDir = (Join-Path $env:USERPROFILE '.dsh\profiles\desktop'),
    [string]$PluginRoot = (Join-Path $env:USERPROFILE '.dsh\plugins'),
    [string]$DshHome = (Join-Path $env:USERPROFILE '.dsh'),
    [switch]$NoStart,
    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
$Name = 'dsh-local-model-toggle'
$CfgName = 'local-model-toggle'   # 配置目录名和包名不同（插件自己写的是这个）
$Port = 8080
$BaseUrl = "http://127.0.0.1:$Port"

function Step($n, $m) { Write-Host ''; Write-Host "[$n] $m" -ForegroundColor White }
function Info($m) { Write-Host "    [*] $m" -ForegroundColor Cyan }
function Ok  ($m) { Write-Host "    [+] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "    [!] $m" -ForegroundColor Yellow }
function Die ($m) { Write-Host "    [x] $m" -ForegroundColor Red; exit 1 }

function Test-Deploy([string]$dir) {
    if (-not $dir) { return $false }
    return (Test-Path (Join-Path $dir 'qwen-deploy.ps1'))
}

function Get-Health {
    try { return [int](Invoke-WebRequest -UseBasicParsing -Uri "$BaseUrl/health" -TimeoutSec 3).StatusCode }
    catch { return 0 }
}

try {
    $src = Split-Path -Parent $MyInvocation.MyCommand.Path
    if (-not $src) { Die '拿不到脚本所在目录' }

    Write-Host ''
    Write-Host '  dsh-local-model-toggle 安装（只装插件）' -ForegroundColor White
    Write-Host '  ---------------------------------------------' -ForegroundColor DarkGray

    # ---------------------------------------------------------------- 0. 环境
    Step 0 '检查环境'
    if (-not (Test-Path (Join-Path $src 'lib\client.js'))) { Die "这个文件夹不完整，缺 lib\client.js：$src" }
    if (-not (Test-Path $ProfileDir)) { Die "找不到 DSH profile：$ProfileDir`n    先用 DSH 打开一次，让它自己建出来。" }
    $pkgPath = Join-Path $ProfileDir 'package.json'
    if (-not (Test-Path $pkgPath)) { Die "找不到 $pkgPath" }
    Ok "DSH profile: $ProfileDir"
    Info "PowerShell $($PSVersionTable.PSVersion)"

    # ---------------------------------------------------------------- 1. 部署目录
    Step 1 '找已有的模型部署目录'
    $resolved = ''
    if (Test-Deploy $DeployDir) {
        $resolved = $DeployDir
        Ok "使用 -DeployDir：$resolved"
    } else {
        if ($DeployDir) { Warn "这个目录里没有 qwen-deploy.ps1：$DeployDir" }
        $cfgPath = Join-Path $DshHome "$CfgName\config.json"
        if (Test-Path $cfgPath) {
            try {
                # 配置是 UTF-8 无 BOM；但普通 PowerShell 用 Out-File 写过的话会变成 ANSI，两种都认
                $txt = ([IO.File]::ReadAllText($cfgPath)).TrimStart([char]0xFEFF)
                if ($txt.Contains([char]0xFFFD)) { $txt = [Text.Encoding]::Default.GetString([IO.File]::ReadAllBytes($cfgPath)) }
                $cfg = $txt | ConvertFrom-Json
                if ($cfg.deployDir -and (Test-Deploy $cfg.deployDir)) {
                    $resolved = $cfg.deployDir
                    Ok "沿用上次配置：$resolved"
                }
            } catch { }
        }
        if (-not $resolved) {
            Write-Host ''
            Write-Host '  没找到部署目录。这个脚本不会替你下载模型，请指定一个已经有模型的目录：' -ForegroundColor Yellow
            Write-Host '    powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -DeployDir "D:\...\你的部署夹"' -ForegroundColor Gray
            Write-Host '  （那个目录里应该有 qwen-deploy.ps1 和 llama.cpp\models\*.gguf）' -ForegroundColor DarkGray
            Die '缺少部署目录，已停止（没有做任何改动）。'
        }
    }

    # 顺手体检：有脚本但没运行时/模型，也让他知道
    $exe  = Get-ChildItem $resolved -Recurse -Filter 'llama-server.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
    $gguf = Get-ChildItem $resolved -Recurse -Filter '*.gguf' -ErrorAction SilentlyContinue | Sort-Object Length -Descending | Select-Object -First 1
    if ($exe) { Ok "运行时：$($exe.FullName)" } else { Warn '目录里没有 llama-server.exe，首次启动会去下载运行时（约 1.5 GB）' }
    if ($gguf) { Ok ("模型：{0}  {1:N1} GB" -f $gguf.Name, ($gguf.Length / 1GB)) } else { Warn '目录里没有 .gguf，首次启动会去下载模型（约 6 GB）' }

    $pluginDst = Join-Path $PluginRoot $Name
    $linkPath  = Join-Path $ProfileDir "node_modules\$Name"
    $cfgDir    = Join-Path $DshHome $CfgName
    $cfgFile   = Join-Path $cfgDir 'config.json'

    if ($DryRun) {
        Write-Host ''
        Ok 'DryRun 结束：以上是解析结果，没有写任何文件。'
        Info "将安装插件到 $pluginDst"
        Info "将写配置 $cfgFile -> deployDir=$resolved"
        if (-not $NoStart) { Info "将启动 $resolved\qwen-deploy.ps1 -Background" }
        exit 0
    }

    # ---------------------------------------------------------------- 2. 装插件
    Step 2 '安装侧栏插件'
    New-Item -ItemType Directory -Force -Path $PluginRoot | Out-Null
    if (Test-Path $pluginDst) { Remove-Item $pluginDst -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $pluginDst | Out-Null
    Copy-Item (Join-Path $src 'lib') -Destination $pluginDst -Recurse -Force
    Copy-Item (Join-Path $src 'cordis.patch.yml') -Destination $pluginDst -Force
    Copy-Item (Join-Path $src 'package.json') -Destination $pluginDst -Force
    Ok "已复制到 $pluginDst"

    if (Test-Path $linkPath) {
        $item = Get-Item $linkPath -Force
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { cmd /c rmdir "`"$linkPath`"" | Out-Null }
        else { Remove-Item $linkPath -Recurse -Force }
    }
    $r = cmd /c mklink /J "`"$linkPath`"" "`"$pluginDst`"" 2>&1
    if ($LASTEXITCODE -ne 0) { Die "建 Junction 失败：$r" }
    Ok 'Junction 已建立'

    Copy-Item $pkgPath "$pkgPath.bak-toggle-$(Get-Date -Format 'yyyyMMdd-HHmmss')" -Force
    $pkg = ([IO.File]::ReadAllText($pkgPath)) | ConvertFrom-Json
    if (-not $pkg.dependencies) { $pkg | Add-Member -NotePropertyName dependencies -NotePropertyValue ([pscustomobject]@{}) }
    if (-not $pkg.dsh) { $pkg | Add-Member -NotePropertyName dsh -NotePropertyValue ([pscustomobject]@{}) }
    if (-not $pkg.dsh.profile) { $pkg.dsh | Add-Member -NotePropertyName profile -NotePropertyValue ([pscustomobject]@{}) }
    if (-not $pkg.dsh.profile.bundles) { $pkg.dsh.profile | Add-Member -NotePropertyName bundles -NotePropertyValue @() }

    $pkg.dependencies | Add-Member -NotePropertyName $Name -NotePropertyValue ('link:' + ($pluginDst -replace '\\', '/')) -Force
    $bundles = @($pkg.dsh.profile.bundles)
    if ($bundles -notcontains $Name) {
        $idx = 0
        for ($i = 0; $i -lt $bundles.Count; $i++) { if ($bundles[$i] -like '@deepseek-ai/*') { $idx = $i + 1 } }
        $nb = @()
        if ($idx -gt 0) { $nb += $bundles[0..($idx - 1)] }
        $nb += $Name
        if ($idx -lt $bundles.Count) { $nb += $bundles[$idx..($bundles.Count - 1)] }
        $pkg.dsh.profile.bundles = $nb
        Ok "已登记到 profile（bundle 共 $((@($pkg.dsh.profile.bundles)).Count) 个）"
    } else {
        Ok 'profile 里已有这条 bundle，未重复添加'
    }
    [IO.File]::WriteAllText($pkgPath, ($pkg | ConvertTo-Json -Depth 20), (New-Object Text.UTF8Encoding($false)))

    # ---------------------------------------------------------------- 3. 写配置
    Step 3 '写插件配置'
    New-Item -ItemType Directory -Force -Path $cfgDir | Out-Null
    $cfgObj = [pscustomobject]@{
        deployDir   = $resolved
        autoStop    = $true
        idleMinutes = 10
    }
    [IO.File]::WriteAllText($cfgFile, ($cfgObj | ConvertTo-Json -Depth 5), (New-Object Text.UTF8Encoding($false)))
    Ok "deployDir = $resolved"

    # ---------------------------------------------------------------- 4. 起服务
    if ($NoStart) {
        Step 4 '启动模型（已跳过）'
    } else {
        Step 4 '启动模型服务'
        if ((Get-Health) -eq 200) {
            Ok "已经在跑了：$BaseUrl"
        } else {
            $dep = Join-Path $resolved 'qwen-deploy.ps1'
            Info "调用 $dep -Background"
            Start-Process -FilePath 'powershell.exe' `
                -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$dep`"", '-Root', "`"$resolved`"", '-Background') `
                -WindowStyle Hidden | Out-Null
            $deadline = (Get-Date).AddSeconds(600)
            $ready = $false
            while ((Get-Date) -lt $deadline) {
                Start-Sleep -Seconds 3
                if ((Get-Health) -eq 200) { $ready = $true; break }
                Write-Host '.' -NoNewline -ForegroundColor DarkGray
            }
            Write-Host ''
            if ($ready) { Ok "服务已就绪：$BaseUrl" } else { Warn '10 分钟内没等到 /health 200，可能还在加载，稍后看开关上的提示。' }
        }
    }

    # ---------------------------------------------------------------- 5. 收尾
    Write-Host ''
    Write-Host '  ---------------------------------------------' -ForegroundColor DarkGray
    Ok '装好了。'
    Write-Host '    最后一步：完全退出 DSH（托盘右键 → 退出）再重新打开。' -ForegroundColor White
    Write-Host '    左下角会出现蓝色胶囊「本地 Qwen3.5-9B」：左键启停，右键换目录/闲置自动关闭。' -ForegroundColor DarkGray
    Write-Host ''
    Write-Host "    部署目录 : $resolved" -ForegroundColor DarkGray
    Write-Host "    配置文件 : $cfgFile" -ForegroundColor DarkGray
    Write-Host "    API 地址 : $BaseUrl/v1" -ForegroundColor DarkGray
    Write-Host '    后悔了：跑一次 uninstall.ps1 就能撤干净。' -ForegroundColor DarkGray
} catch {
    Write-Host ''
    Write-Host "[x] 出错了：$($_.Exception.Message)" -ForegroundColor Red
    Write-Host "    位置：第 $($_.InvocationInfo.ScriptLineNumber) 行" -ForegroundColor DarkGray
    Write-Host '    修好后可以重跑，脚本是幂等的。' -ForegroundColor DarkGray
    exit 1
}
