@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo.
echo   dsh-local-model-toggle - uninstall
echo   ---------------------------------------------
echo.
echo   This removes the plugin from the DSH profile.
echo   Your model / llama.cpp folder is NOT touched.
echo.
choice /c YN /n /m "  Continue? [Y/N] "
if errorlevel 2 goto :cancel

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
set RC=%ERRORLEVEL%
echo.
if "%RC%"=="0" (
    echo   [i] Removed. Fully quit DSH and reopen it.
) else (
    echo   [i] Exit code %RC% - read the messages above.
)
echo.
pause >nul
exit /b 0

:cancel
echo.
echo   Cancelled.
echo.
pause >nul
