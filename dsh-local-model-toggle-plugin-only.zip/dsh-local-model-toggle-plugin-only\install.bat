@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo.
echo   dsh-local-model-toggle - one-click install
echo   ---------------------------------------------
echo.

rem Pass a deploy directory as the first argument, otherwise setup.ps1
rem falls back to the deployDir stored in config.json.
if "%~1"=="" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -DeployDir "%~1"
)

set RC=%ERRORLEVEL%
echo.
if "%RC%"=="0" (
    echo   [i] Done. Fully quit DSH (tray icon - Quit) and reopen it.
) else (
    echo   [i] Exit code %RC% - read the messages above.
)
echo.
pause >nul
