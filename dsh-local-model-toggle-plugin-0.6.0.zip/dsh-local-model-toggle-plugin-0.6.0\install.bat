@echo off
setlocal enableextensions
cd /d "%~dp0"
echo.
echo   dsh-local-model-toggle 0.5.0 - install
echo   ---------------------------------------
echo.
if "%~1"=="" goto plain
echo %~1 | findstr /b /c:"-" >nul
if errorlevel 1 goto folder
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" %*
goto done
:folder
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -DeployDir "%~1"
goto done
:plain
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
:done
echo.
echo   Press any key to close this window.
pause >nul