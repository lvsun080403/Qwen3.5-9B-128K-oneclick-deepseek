﻿# dsh-local-model-toggle 卸载脚本（Windows PowerShell 5.1 兼容）
#
#   1. 从 profile 的 package.json 里摘掉依赖与 bundle（改前备份）
#   2. 删掉 node_modules 里的 Junction
#   3. 删掉 %USERPROFILE%\.dsh\plugins\dsh-local-model-toggle
#
# 用法：
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\uninstall.ps1
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\uninstall.ps1 -KeepFiles

param(
    [string]$ProfileDir = (Join-Path $env:USERPROFILE '.dsh\profiles\desktop'),
    [string]$PluginRoot = (Join-Path $env:USERPROFILE '.dsh\plugins'),
    [switch]$KeepFiles,
    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
$Name = 'dsh-local-model-toggle'

function Info($m) { Write-Host "[*] $m" -ForegroundColor Cyan }
function Ok  ($m) { Write-Host "[+] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "[!] $m" -ForegroundColor Yellow }
function Die ($m) { Write-Host "[x] $m" -ForegroundColor Red; exit 1 }

try {
    $pkgPath  = Join-Path $ProfileDir 'package.json'
    $dst      = Join-Path $PluginRoot $Name
    $linkPath = Join-Path $ProfileDir "node_modules\$Name"

    if (-not (Test-Path $pkgPath)) { Die "找不到 $pkgPath" }
    if ($DryRun) { Ok 'DryRun：不会做任何改动。'; exit 0 }

    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    Copy-Item $pkgPath "$pkgPath.bak-uninstall-$stamp" -Force
    Info "已备份 package.json"

    $pkg = ([IO.File]::ReadAllText($pkgPath)) | ConvertFrom-Json
    if ($pkg.dependencies -and $pkg.dependencies.$Name) {
        $pkg.dependencies.PSObject.Properties.Remove($Name)
        Info 'dependencies 里已移除'
    }
    if ($pkg.dsh -and $pkg.dsh.profile -and $pkg.dsh.profile.bundles) {
        $pkg.dsh.profile.bundles = @($pkg.dsh.profile.bundles | Where-Object { $_ -ne $Name })
        Info "bundles 里已移除（剩 $((@($pkg.dsh.profile.bundles)).Count) 个）"
    }
    [IO.File]::WriteAllText($pkgPath, ($pkg | ConvertTo-Json -Depth 20), (New-Object Text.UTF8Encoding($false)))

    if (Test-Path $linkPath) {
        $item = Get-Item $linkPath -Force
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { cmd /c rmdir "`"$linkPath`"" | Out-Null }
        else { Remove-Item $linkPath -Recurse -Force }
        Info 'Junction 已删除'
    }

    if (-not $KeepFiles -and (Test-Path $dst)) {
        Remove-Item $dst -Recurse -Force
        Info "插件目录已删除：$dst"
    }

    Write-Host ''
    Ok '卸载完成。完全退出 DSH 再重新打开。'
} catch {
    Write-Host "[x] 出错了：$($_.Exception.Message)" -ForegroundColor Red
    Write-Host "    位置：第 $($_.InvocationInfo.ScriptLineNumber) 行" -ForegroundColor DarkGray
    exit 1
}
