﻿# dsh-local-model-toggle 0.5.0 安装脚本（只装插件，模型已经有了）
#
# 前提：机器上已经有一个 llama.cpp 部署目录，里面至少有
#   qwen-deploy.ps1（或 serve-bonsai.ps1）、llama.cpp\llama-server.exe、llama.cpp\models\*.gguf
#
# 这个脚本做四件事：
#   1. 从 DSH 的 cordis.patch.yml 里找出所有"外接本地模型"（baseURL 指向本机回环的 provider）
#   2. 把插件复制到 ~\.dsh\plugins 并 Junction 进 profile，登记依赖与 bundle
#   3. 写插件配置（v2：按模型分别记部署夹 + 记住当前选中），并绑定到你这个部署目录
#   4. 可选：顺手把模型服务拉起来
#
# 用法（在本文件夹里双击 install.bat，或）：
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -DeployDir "D:\1\Qwen3.5-9B · Q4_K_XL"
#   ... -Provider local-qwen      指定这份部署夹属于哪个 provider（默认自动挑）
#   ... -NoStart                  只装不启动
#   ... -DryRun                   只看会做什么，不写任何文件
#
# 不传 -DeployDir 时优先沿用 config.json 里记过的目录；都没有就停下，不乱猜。

param(
    [string]$DeployDir = '',
    [string]$Provider = '',
    [string]$ProfileDir = (Join-Path $env:USERPROFILE '.dsh\profiles\desktop'),
    [string]$PluginRoot = (Join-Path $env:USERPROFILE '.dsh\plugins'),
    [string]$DshHome = (Join-Path $env:USERPROFILE '.dsh'),
    [switch]$NoStart,
    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
$Name = 'dsh-local-model-toggle'
$CfgName = 'local-model-toggle'   # 配置目录名和包名不同（插件自己写的就是这个）
$Version = '0.5.0'

function Step($n, $m) { Write-Host ''; Write-Host "[$n] $m" -ForegroundColor White }
function Info($m) { Write-Host "    [*] $m" -ForegroundColor Cyan }
function Ok  ($m) { Write-Host "    [+] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "    [!] $m" -ForegroundColor Yellow }
function Die ($m) { Write-Host "    [x] $m" -ForegroundColor Red; exit 1 }

function Test-Deploy([string]$dir) {
    if (-not $dir) { return $false }
    if (Test-Path (Join-Path $dir 'qwen-deploy.ps1')) { return $true }
    if (Test-Path (Join-Path $dir 'serve-bonsai.ps1')) { return $true }
    # 打包形态（如 bonsai-27b-72k）：启动脚本在 scriptsserve.ps1
    return (Test-Path (Join-Path (Join-Path $dir 'scripts') 'serve.ps1'))
}

function Get-Launcher([string]$dir) {
    if (Test-Path (Join-Path $dir 'serve-bonsai.ps1')) { return 'serve-bonsai.ps1' }
    if (Test-Path (Join-Path $dir 'qwen-deploy.ps1')) { return 'qwen-deploy.ps1' }
    return Join-Path 'scripts' 'serve.ps1'
}

function Get-Health([int]$port) {
    try { return [int](Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$port/health" -TimeoutSec 3).StatusCode }
    catch { return 0 }
}

# 从 cordis.patch.yml 里挑出 baseURL 指向本机的 provider（id + 端口）。
# 不依赖 yaml 模块：找 baseURL 行，再往上找缩进更浅的那个 `xxx:` 行当 provider id。
function Get-LocalProviders([string]$patchPath) {
    $out = @()
    if (-not (Test-Path $patchPath)) { return $out }
    $lines = [IO.File]::ReadAllLines($patchPath)
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $line = $lines[$i]
        $m = [regex]::Match($line, '^\s*baseURL:\s*[''"]?(https?://([^/''"]+))')
        if (-not $m.Success) { continue }
        $hostPart = $m.Groups[2].Value
        if ($hostPart -notmatch '^(127\.0\.0\.1|localhost|\[::1\]|0\.0\.0\.0)(:\d+)?$') { continue }
        $pm = [regex]::Match($hostPart, ':(\d+)$')
        $port = if ($pm.Success) { [int]$pm.Groups[1].Value } else { 80 }
        $indent = ([regex]::Match($line, '^(\s*)')).Groups[1].Length
        $id = ''
        for ($j = $i - 1; $j -ge 0; $j--) {
            $mj = [regex]::Match($lines[$j], '^(\s*)([A-Za-z0-9_.\-]+):\s*$')
            if (-not $mj.Success) { continue }
            if ($mj.Groups[1].Length -ge $indent) { continue }
            $key = $mj.Groups[2].Value
            if ($key -in @('providers', 'config', 'models', 'llm-pi-ai', 'name', 'dsh')) { continue }
            $id = $key
            break
        }
        if ($id) { $out += [pscustomobject]@{ Id = $id; Port = $port } }
    }
    return $out
}

function Read-Json([string]$path) {
    if (-not (Test-Path $path)) { return $null }
    $txt = ([IO.File]::ReadAllText($path)).TrimStart([char]0xFEFF)
    # 被记事本存成 ANSI 的话会有 U+FFFD，退回 ANSI 再读一次
    if ($txt.Contains([char]0xFFFD)) { $txt = [Text.Encoding]::Default.GetString([IO.File]::ReadAllBytes($path)) }
    return $txt | ConvertFrom-Json
}

try {
    $src = Split-Path -Parent $MyInvocation.MyCommand.Path
    if (-not $src) { Die '拿不到脚本所在目录' }

    Write-Host ''
    Write-Host "  dsh-local-model-toggle $Version 安装（只装插件）" -ForegroundColor White
    Write-Host '  --------------------------------------------------' -ForegroundColor DarkGray

    # ---------------------------------------------------------------- 0. 环境
    Step 0 '检查环境'
    foreach ($f in @('lib\client.js', 'lib\index.js', 'package.json')) {
        if (-not (Test-Path (Join-Path $src $f))) { Die "这个文件夹不完整，缺 $f：$src" }
    }
    if (-not (Test-Path $ProfileDir)) { Die "找不到 DSH profile：$ProfileDir`n    先用 DSH 打开一次，让它自己建出来。" }
    $pkgPath = Join-Path $ProfileDir 'package.json'
    if (-not (Test-Path $pkgPath)) { Die "找不到 $pkgPath" }
    Ok "DSH profile: $ProfileDir"
    Info "PowerShell $($PSVersionTable.PSVersion)"

    # ---------------------------------------------------------------- 1. 部署目录
    Step 1 '找已有的模型部署目录'
    $cfgPath = Join-Path $DshHome "$CfgName\config.json"
    $oldCfg = $null
    try { $oldCfg = Read-Json $cfgPath } catch { $oldCfg = $null }

    $resolved = ''
    if (Test-Deploy $DeployDir) {
        $resolved = $DeployDir
        Ok "使用 -DeployDir：$resolved"
    } else {
        if ($DeployDir) { Warn "这个目录里没有 qwen-deploy.ps1 / serve-bonsai.ps1 / scripts\serve.ps1：$DeployDir" }
        if ($oldCfg -and $oldCfg.dirs) {
            foreach ($p in $oldCfg.dirs.PSObject.Properties) {
                if (Test-Deploy $p.Value) { $resolved = $p.Value; Ok "沿用上次配置（$($p.Name)）：$resolved"; break }
            }
        }
        if (-not $resolved -and $oldCfg -and $oldCfg.deployDir -and (Test-Deploy $oldCfg.deployDir)) {
            $resolved = $oldCfg.deployDir
            Ok "沿用上次配置：$resolved"
        }
        if (-not $resolved) {
            Write-Host ''
            Write-Host '  没找到部署目录。这个脚本不会替你下载模型，请指定一个已经有模型的目录：' -ForegroundColor Yellow
            Write-Host '    install.bat "D:\...\你的部署夹"' -ForegroundColor Gray
            Write-Host '  （里面应该有 qwen-deploy.ps1 / serve-bonsai.ps1 / scripts\serve.ps1，以及模型文件）' -ForegroundColor DarkGray
            Die '缺少部署目录，已停止（没有做任何改动）。'
        }
    }

    $exe  = Get-ChildItem $resolved -Recurse -Filter 'llama-server.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
    $gguf = Get-ChildItem $resolved -Recurse -Filter '*.gguf' -ErrorAction SilentlyContinue | Sort-Object Length -Descending | Select-Object -First 1
    if ($exe) { Ok "运行时：$($exe.FullName)" } else { Warn '目录里没有 llama-server.exe，首次启动会去下载运行时' }
    if ($gguf) { Ok ("模型：{0}  {1:N1} GB" -f $gguf.Name, ($gguf.Length / 1GB)) } else { Warn '目录里没有 .gguf，首次启动会去下载模型' }

    # ---------------------------------------------------------------- 2. 本地 provider
    Step 2 '从 DSH 配置里找外接本地模型'
    $patch = Join-Path $ProfileDir 'cordis.patch.yml'
    $locals = Get-LocalProviders $patch
    if (@($locals).Count -eq 0) {
        Warn 'cordis.patch.yml 里没有找到指向本机的 provider'
        Warn '先在 DSH 里添加「自定义模型 API」（端点形如 http://127.0.0.1:8080/v1），再重跑本脚本'
    } else {
        foreach ($p in $locals) { Info ("{0}  ->  127.0.0.1:{1}" -f $p.Id, $p.Port) }
    }

    $target = $null
    if ($Provider) {
        $target = $locals | Where-Object { $_.Id -eq $Provider } | Select-Object -First 1
        if (-not $target) { Die "配置里没有这个 provider：$Provider" }
    } elseif (@($locals).Count -gt 0) {
        # 先按「部署夹里启动脚本的默认端口」去配 provider（qwen-deploy.ps1 默认 8080，打包形态 scripts\serve.ps1 默认 18200）
        $launcherFile = Join-Path $resolved (Get-Launcher $resolved)
        $guessPort = 0
        if (Test-Path $launcherFile) {
            $m2 = Select-String -Path $launcherFile -Pattern '\$Port\s*=\s*(\d+)' | Select-Object -First 1
            if ($m2) { $guessPort = [int]$m2.Matches[0].Groups[1].Value }
        }
        if ($guessPort -gt 0) {
            $target = $locals | Where-Object { $_.Port -eq $guessPort } | Select-Object -First 1
            if ($target) { Info "部署夹默认端口 $guessPort → 命中 provider $($target.Id)" }
        }
        if (-not $target) { $target = $locals | Where-Object { $_.Port -eq 8080 } | Select-Object -First 1 }
        if (-not $target) { $target = $locals | Sort-Object Port | Select-Object -First 1 }
    }

    $port = if ($target) { $target.Port } else { 8080 }
    if ($target) { Ok "这份部署夹绑定到 $($target.Id)（端口 $port）" } else { Warn "没绑定 provider，按端口 $port 处理" }

    $pluginDst = Join-Path $PluginRoot $Name
    $linkPath  = Join-Path $ProfileDir "node_modules\$Name"
    $cfgDir    = Join-Path $DshHome $CfgName

    if ($DryRun) {
        Write-Host ''
        Ok 'DryRun 结束：以上是解析结果，没有写任何文件。'
        Info "将安装插件到 $pluginDst"
        Info "将写 $cfgPath ：active=$(if ($target) { $target.Id } else { '' })  dirs[$(if ($target) { $target.Id } else { '__legacy' })]=$resolved"
        if (-not $NoStart) { Info "将启动 $(Join-Path $resolved (Get-Launcher $resolved)) -Background -Port $port" }
        exit 0
    }

    # ---------------------------------------------------------------- 3. 装插件
    Step 3 '安装侧栏插件'
    New-Item -ItemType Directory -Force -Path $PluginRoot | Out-Null
    if (Test-Path $pluginDst) { Remove-Item $pluginDst -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $pluginDst | Out-Null
    Copy-Item (Join-Path $src 'lib') -Destination $pluginDst -Recurse -Force
    Copy-Item (Join-Path $src 'cordis.patch.yml') -Destination $pluginDst -Force
    Copy-Item (Join-Path $src 'package.json') -Destination $pluginDst -Force
    Ok "已复制到 $pluginDst"

    if (Test-Path $linkPath) {
        $item = Get-Item $linkPath -Force
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { cmd /c rmdir "`"$linkPath`"" | Out-Null }
        else { Remove-Item $linkPath -Recurse -Force }
    }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $linkPath) | Out-Null
    $r = cmd /c mklink /J "`"$linkPath`"" "`"$pluginDst`"" 2>&1
    if ($LASTEXITCODE -ne 0) { Die "建 Junction 失败：$r" }
    Ok 'Junction 已建立'

    Copy-Item $pkgPath "$pkgPath.bak-toggle-$(Get-Date -Format 'yyyyMMdd-HHmmss')" -Force
    $pkg = ([IO.File]::ReadAllText($pkgPath)) | ConvertFrom-Json
    if (-not $pkg.dependencies) { $pkg | Add-Member -NotePropertyName dependencies -NotePropertyValue ([pscustomobject]@{}) }
    if (-not $pkg.dsh) { $pkg | Add-Member -NotePropertyName dsh -NotePropertyValue ([pscustomobject]@{}) }
    if (-not $pkg.dsh.profile) { $pkg.dsh | Add-Member -NotePropertyName profile -NotePropertyValue ([pscustomobject]@{}) }
    if (-not $pkg.dsh.profile.bundles) { $pkg.dsh.profile | Add-Member -NotePropertyName bundles -NotePropertyValue @() }

    $pkg.dependencies | Add-Member -NotePropertyName $Name -NotePropertyValue ('link:' + ($pluginDst -replace '\\', '/')) -Force
    $bundles = @($pkg.dsh.profile.bundles)
    if ($bundles -notcontains $Name) {
        $idx = 0
        for ($i = 0; $i -lt $bundles.Count; $i++) { if ($bundles[$i] -like '@deepseek-ai/*') { $idx = $i + 1 } }
        $nb = @()
        if ($idx -gt 0) { $nb += $bundles[0..($idx - 1)] }
        $nb += $Name
        if ($idx -lt $bundles.Count) { $nb += $bundles[$idx..($bundles.Count - 1)] }
        $pkg.dsh.profile.bundles = $nb
        Ok "已登记到 profile（bundle 共 $((@($pkg.dsh.profile.bundles)).Count) 个）"
    } else {
        Ok 'profile 里已有这条 bundle，未重复添加'
    }
    [IO.File]::WriteAllText($pkgPath, ($pkg | ConvertTo-Json -Depth 20), (New-Object Text.UTF8Encoding($false)))

    # ---------------------------------------------------------------- 4. 写配置（v2）
    Step 4 '写插件配置'
    New-Item -ItemType Directory -Force -Path $cfgDir | Out-Null

    $dirs = [ordered]@{}
    if ($oldCfg -and $oldCfg.dirs) { foreach ($p in $oldCfg.dirs.PSObject.Properties) { $dirs[$p.Name] = $p.Value } }
    $key = if ($target) { $target.Id } else { '__legacy' }
    $dirs[$key] = $resolved

    $active = if ($oldCfg -and $oldCfg.active) { $oldCfg.active } else { $key }
    $autoStop = $true
    $idle = 10
    if ($oldCfg) {
        if ($oldCfg.PSObject.Properties.Name -contains 'autoStop') { $autoStop = [bool]$oldCfg.autoStop }
        if ($oldCfg.PSObject.Properties.Name -contains 'idleMinutes') { $idle = [int]$oldCfg.idleMinutes }
    }

    $cfgObj = [ordered]@{
        version     = 2
        active      = $active
        autoStop    = $autoStop
        idleMinutes = $idle
        dirs        = $dirs
    }
    if ($oldCfg -and $oldCfg.PSObject.Properties.Name -contains 'ctx') { $cfgObj.ctx = $oldCfg.ctx }

    [IO.File]::WriteAllText($cfgPath, ($cfgObj | ConvertTo-Json -Depth 8), (New-Object Text.UTF8Encoding($false)))
    Ok "dirs[$key] = $resolved"
    Ok "active = $active"

    # ---------------------------------------------------------------- 5. 起服务
    $launcher = Get-Launcher $resolved
    if ($NoStart) {
        Step 5 '启动模型（已跳过）'
    } else {
        Step 5 '启动模型服务'
        if ((Get-Health $port) -eq 200) {
            Ok "已经在跑了：http://127.0.0.1:$port"
        } else {
            $dep = Join-Path $resolved $launcher
            Info "调用 $dep -Background -Port $port"
            $args = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$dep`"", '-Background', '-Port', "$port")
            if ($launcher -like '*serve.ps1') {
                # 打包形态的 serve.ps1 用 -Context（单位 token），且默认就是 73728，不需要覆盖
            } elseif ($launcher -eq 'serve-bonsai.ps1') {
                $args += @('-Ctx', '32768')
            }
            Start-Process -FilePath 'powershell.exe' -ArgumentList $args -WindowStyle Hidden | Out-Null
            $deadline = (Get-Date).AddSeconds(600)
            $ready = $false
            while ((Get-Date) -lt $deadline) {
                Start-Sleep -Seconds 3
                if ((Get-Health $port) -eq 200) { $ready = $true; break }
                Write-Host '.' -NoNewline -ForegroundColor DarkGray
            }
            Write-Host ''
            if ($ready) { Ok "服务已就绪：http://127.0.0.1:$port" } else { Warn '10 分钟内没等到 /health 200，可能还在加载，稍后看开关上的提示。' }
        }
    }

    # ---------------------------------------------------------------- 6. 收尾
    Write-Host ''
    Write-Host '  --------------------------------------------------' -ForegroundColor DarkGray
    Ok '装好了。'
    Write-Host '    最后一步：完全退出 DSH（托盘右键 → 退出）再重新打开。' -ForegroundColor White
    Write-Host '    左下角会出现蓝色胶囊：左键启停当前模型，右键换模型 / 换部署夹 / 闲置自动关闭。' -ForegroundColor DarkGray
    Write-Host ''
    Write-Host "    部署目录 : $resolved" -ForegroundColor DarkGray
    Write-Host "    绑定模型 : $(if ($target) { $target.Id } else { '(未绑定 provider)' })  端口 $port" -ForegroundColor DarkGray
    Write-Host "    配置文件 : $cfgPath" -ForegroundColor DarkGray
    Write-Host "    API 地址 : http://127.0.0.1:$port/v1" -ForegroundColor DarkGray
    Write-Host '    后悔了：跑一次 uninstall.ps1 就能撤干净。' -ForegroundColor DarkGray
} catch {
    Write-Host ''
    Write-Host "[x] 出错了：$($_.Exception.Message)" -ForegroundColor Red
    Write-Host "    位置：第 $($_.InvocationInfo.ScriptLineNumber) 行" -ForegroundColor DarkGray
    Write-Host '    修好后可以重跑，脚本是幂等的。' -ForegroundColor DarkGray
    exit 1
}
